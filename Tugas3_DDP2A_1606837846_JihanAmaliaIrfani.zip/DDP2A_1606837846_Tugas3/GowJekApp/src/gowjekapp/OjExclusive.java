/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public class OjExclusive extends OwJek implements Calculateable{
	/**
	 * constructor dari subclass ini dengan inputan jarak
	 * @param jarak dalam km tipe double
	 */
	public OjExclusive(double jarak){
		//mengambil insvar superclass dengan inutan default
		super(2016, 0, 500, 5000, 0, 0, 10000, 5, 50, jarak);
	}
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar sesuai jaraknya  dan harga ketetapan
	 * @return hasil perhitungan harga
	 */
	@Override
	public double getKmSel(){
		return (5000 * super.getJarak());
	}
	/**
	 * method accessor getter untuk mendapatkan potongan harga 
	 * @return potongan harga
	 */
	@Override
	public double getPromo(){
		//potongan : (harga fixed + harga kmsel) * 50%
		double potongan = 50 * (this.getFixedCost() + this.getKmSel()) / 100;
		return potongan;	//mengembalikan potongan harga
	}
	/**
	 * method accessor getter untuk mendapatkan harga proteksi
	 * @return proteksi, harga proteksi
	 */
	public double getProtectionCost(){
		//penghitungan harga proteksi dengan : 5% * (harga fixed + harga kmsel - potongan harga)
		return (5 *(this.getFixedCost() + this.getKmSel() - this.getPromo()) / 100);
	}  
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar dengan jarak terpeneknya
	 * @param koordinat sebelum dan koordinat sesudah
	 * @return total, harga totalnya
	 */
	@Override
	public double getCost(int from, int to){
		//menampung nilai total dengan perhitungan
		//penambahan harga dari harga fixed + perhitungan pada method getKmSel() - potongan harga + harga proteksi
		return ((double) this.getFixedCost() + this.getKmSel() - this.getPromo() + this.getProtectionCost());
	} 

}

