/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public interface Calculateable {
    /**
	 * method abstract untuk penghitungan total harga perjalanan
	 * @param from
	 * @param to
	 * @return
	 */
	public double getCost(int from, int to);
	/**
	 * method abstract untuk penghitugan potongan harga
	 * @return
	 */
	public double getPromo();
	/**
	 * method abstract untuk penghitungan harga sesuai jarak 
	 * dan juga ketetapan harga per jaraknya
	 * @return
	 */
	public double getKmSel();
}
