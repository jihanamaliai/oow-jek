/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public class OjSporty extends OwJek implements Calculateable{
	/**
	 * constructor dari subclass ini dengan inputan jarak
	 * @param jarak dalam km tipe double
	 */
	public OjSporty( double jarak){
		//mengambil insvar superclass dengan inutan default
		super(2015, 140, 0, 3000, 0, 20000, 0, 10, 60, jarak);
	}
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar sesuai jaraknya 
	 * dikurangi dengan jarak 5 km
	 * @return hasil perhitungan harga
	 */
	@Override
	public double getKmSel(){
		//perhitungan dengan harga tetap * (jarak - 5)
		return (3000* (super.getJarak() - 5 ));
	}
	
	/**
	 * method accessor getter untuk mendapatkan potongan harga dengan ketentuan
	 * jika ia kurang dari 8 km maka tidak mendapat potongan, dan sebaliknya
	 * @return potongan harga
	 */
	@Override
	public double getPromo(){
		double potongan = 0;	//menampung harga potongan
		int banding = Double.compare(this.getJarak(), 8.0);	//menampung nilai jarak dan yang akan dibandingkan
		if (banding >= 0){	//jika ia lebih dari atau sama dengan 8 (jarak)
			//potongan : (harga 5 km awal + 3 * harga per kilometer) * 60%
			int potongan1 = (this.getFirst5KmCost() + (3 * this.getCostPerKm())) * 60 / 100;
			potongan += potongan1;	//update nilai potongan harga
		}else if (banding < 0 ){	//jika kurang dari 8 km (jarak)
			potongan += 0;	//tidak ada penambahan harga potongan
		}
		return potongan;	//mengembalikan harga potongan
		
	}
	
	/**
	 * method accessor getter untuk mendapatkan harga proteksi
	 * @return proteksi, harga proteksi
	 */
	public double getProtectionCost(){
		//penghitungan harga proteksi dengan : 10% * (harga 5 km awal - promo)
		double proteksi = 10 * (this.getFirst5KmCost() + this.getKmSel() - this.getPromo()) /100;
		return proteksi;	//mengambalikan harga proteksi
	}
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar dengan jarak terpeneknya
	 * @param koordinat sebelum dan koordinat sesudah
	 * @return total, harga totalnya
	 */
	@Override
	public double getCost(int from, int to){
		//menampung nilai total dengan perhitungan
		//penambahan harga dari 5 kilometer awal + perhitungan pada method getKmSel() - potongan harga 
		double total = this.getFirst5KmCost() + this.getKmSel() - this.getPromo() +this.getProtectionCost();
		return total;	//mengembalikan harga total
	}
	
}

