/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Jihanai
 */
public class Map {
    public static final Integer WIDTH = 100;
    public static final Integer HEIGHT = 50;
    //insvar untuk menampilkan peta
    private Character map[][] = new Character[HEIGHT][WIDTH];
    private char[][] outMap = null;
    //insvar untuk penghitungan
    private int counter = 0;
    private int bestSolution = Integer.MAX_VALUE;
    

	/**
     * constructor kelas Map
     */
    public Map() {
        initMap();
    }

    public Character[][] getMap() {
		return map;
	}

	public void setMap(Character[][] map) {
		this.map = map;
	}
    /**
     * method accessor getter untuk map keluaran yang sudah di copy
     * @return outMap
     */
	public char[][] getOutMap() {
		return outMap;
	}
        public Character getOut(int posX, int posY){
            return this.outMap[posX][posY];
        }

	/**
	 * method mutator setter untuk mengubah map keluaran yang sudah dicopy
	 * @param outMap
	 */
	public void setOutMap(char[][] outMap) {
		this.outMap = outMap;
	}

	/**
	 *method accessor untuk mendapatkan karakter pada koordinat tertentu 
	 * @param posI
	 * @param posJ
	 * @return map[posI][posJ]
	 */
	public Character get(int posI, int posJ){
        return map[posI][posJ];
    }

	/**
	 * method mutator untuk memodif isi karakter pada koordinat tertentu
	 * @param c
	 * @param posI
	 * @param posJ
	 */
    public void set(Character c, int posI, int posJ){
        map[posI][posJ] = c;
    }

    /**
     * method accessor untuk mendapatkan counter
     * @return counter
     */
    public int getCounter() {
		return counter;
	}

    /**
     * merhod mutator untuk mengubah counter
     * @param counter
     */
	public void setCounter(int counter) {
		this.counter = counter;
	}

	/**
	 * method untuk mengisi array2D map
	 */
	private void initMap(){
        BufferedReader br = null;
        FileReader fr = null;

        try {

            fr = new FileReader("map.txt");
            br = new BufferedReader(fr);

            String currentLine;

            int i = 0;
            while ((currentLine = br.readLine()) != null) {
                for(int j = 0; j<WIDTH; j++){
                    map[i][j] = currentLine.charAt(j);
                }
                i++;
            }
            //buka folder ini
            //map.txt?

        } catch (IOException e) {

            e.printStackTrace();

        } finally {

            try {

                if (br != null)
                    br.close();

                if (fr != null)
                    fr.close();

            } catch (IOException ex) {

                ex.printStackTrace();

            }

        }
    }

	/**
	 * method untuk menampilkan peta dengan panjang 50 baris dan lebar 100 kolom
	 */
    public void print(){
        int jjPosAlphabet = 81;
        int jjPosNumber = 0;


        System.out.print("   ");
        for (int j = 0; j<Map.WIDTH; j++){
            if (j % 10 == 0) System.out.print((char)jjPosAlphabet++);
            else System.out.print(" ");
        }

        System.out.println();

        System.out.print("   ");
        for (int j = 0; j<Map.WIDTH; j++){
            System.out.print(jjPosNumber++);
            if (jjPosNumber >= 10) jjPosNumber = 0;
        }

        System.out.println();

        int iiPosAlphabet = 65;
        int iiPosNumber = 0;

        for (int i = 0; i<Map.HEIGHT; i++){

            if (i % 10 == 0) System.out.print((char)iiPosAlphabet++);
            else System.out.print(" ");

            System.out.print(iiPosNumber++);
            if (iiPosNumber >= 10) iiPosNumber = 0;

            System.out.print(" ");

            for (int j = 0; j<Map.WIDTH; j++){
                System.out.print(map[i][j]);
            }
            System.out.println();
        }
    }
    /**
     * method untuk menandakan start awal
     * @param x
     * @param y
     */
    public void solve(int x, int y){
    	this.bestSolution = Integer.MAX_VALUE;
    	if (this.shortestPath(x, y, 0) != Integer.MAX_VALUE){
    		this.outMap[x][y] = 'S';
    		this.map[x][y] = 'S';
    	}
    }
    /**
     * method untuk mencopy hasil perjalanan terpendek pada array2D outMap
     */
    public void copyMaze(){
    	this.outMap = new char[Map.HEIGHT][Map.WIDTH];	//menjadikan panjang dan lebar outMap sesuai dengan array2D map
    	//iterasi
    	for(int i = 0; i < Map.HEIGHT; i++){
    		for (int j = 0 ; j < Map.WIDTH; j++){
    			this.outMap[i][j] = this.map[i][j];	//pengisian array2D sesuai dengan isi Map
    		}
    	}
    }
    /**
     * method untuk memproses ahaisl perjalanan terpendek 
     * dengan konsep backtrackking dan rekursif
     * @param xFrom
     * @param yFrom
     * @param count
     * @return int berupa jarak terpendek
     */
    public int shortestPath(int xFrom, int yFrom, int count){
    	
    	counter++; //mengupdate counter
    	//jika sudah mencapai finish
    	if( this.map[xFrom][yFrom]=='F'){
    		this.bestSolution = count;	//nilai bestsolution diupdate
    		this.copyMaze(); //mengcopy hasil perjalanan terpendek pada array2D outMap
    		return count; //count di update untuk nilai minimumnya
    	}
    	
    	//jika jalan selanjutnya adalah pagar atau jalan yang pernah dijalani
    	if(this.map[xFrom][yFrom]=='#' || this.map[xFrom][yFrom]=='.'){
    		return Integer.MAX_VALUE;	//yg di update adalah nilai maksimumnya
    	}
    	
    	//jika count sama dengan best solution atau sudah jalur terpendek
    	if(count == this.bestSolution){
    		return Integer.MAX_VALUE;	//yang di return adalah nilai maksimumnya
    	}
    	
    	//Backtracking
    	this.map[xFrom][yFrom] = '.'; //mengupdate titik pada kolom tsv
    	
    	int res = Integer.MAX_VALUE;	//untuk pengecekan nilai jalur yang telah dilewati
    	int anotherRes = Integer.MAX_VALUE;	//pengecekan selanjutnya
    	
    	
    	
    	 /* jadi tuh bakal terus update nilai countnya sampe finish atau mungkin bisa jadi yang ada malah return max val, terus nanti dicek kalo dia
    	 * nilainya kurang dari yang  si res itu, nanti resnya bakal diupdate yakan
    	 * terus kalo udah selese iterasinya, nanti dicek deeeh si res kurang dari max val kaga, kalo engga baru return si res ntu.
    	 * max val dibuat 1000 buat dia gak mungkin nilai segitu
    	 */
    	
    	//kanan
    	anotherRes = shortestPath(xFrom, yFrom + 1, count + 1);	//rekursif memanggil untuk ke kanan dengan penambahan count
    	if (anotherRes < res) {res = anotherRes;}	//kalau kurang dari nilai res, res diupdate
    	
    	//atas
    	anotherRes = shortestPath(xFrom - 1, yFrom, count + 1);	//rekursif memanggil untuk ke atas
    	if (anotherRes < res) {res = anotherRes;}	//pengecekan dan update

    	//kiri
    	anotherRes = shortestPath(xFrom, yFrom - 1, count + 1);	//rekursif memanggil untuk ke kiri
    	if (anotherRes < res) {res = anotherRes;}	//pengecekan dan update

    	//bawah
    	anotherRes = shortestPath(xFrom + 1, yFrom, count + 1); //rekursif memanggil untuk ke bawah
    	if (anotherRes < res) {res = anotherRes;}	//pengecekan dan update
    	
    	//di unmark
    	this.map[xFrom][yFrom] = ' ';
    	
    	if (res < Integer.MAX_VALUE){	//pengecekan akhir untuk apakah nilainya kurang dari max value integer
    		return res;	//mengembalikan res
    	}
    	//kalo bukan bagian solusi
    	return Integer.MAX_VALUE;
    	
    }
    /**
     * method untuk menmpilkan peta solusi dengan jarak terpendek
     * @return
     */
    public String toStringSolution(){
    	int jjPosAlphabet = 81;
        int jjPosNumber = 0;
    	if (this.outMap == null){
    		return ("No solution!");
    	}
    	String output = "";
    	output += ("   ");
        for (int j = 0; j<Map.WIDTH; j++){
            if (j % 10 == 0) output += ((char)jjPosAlphabet++);
            else output+=(" ");
        }
        output+=("\n");

        output += ("   ");
        for (int j = 0; j<Map.WIDTH; j++){
            output += (jjPosNumber++);
            if (jjPosNumber >= 10) jjPosNumber = 0;
        }

        output += ("\n");
        
        int iiPosAlphabet = 65;
        int iiPosNumber = 0;

        for (int i = 0; i<Map.HEIGHT; i++){

            if (i % 10 == 0) output += ((char)iiPosAlphabet++);
            else output += (" ");

            output += (iiPosNumber++);
            if (iiPosNumber >= 10) iiPosNumber = 0;

            output += (" ");

            for (int j = 0; j<Map.WIDTH; j++){
                output += (this.outMap[i][j]);
            }
            output += ("\n");
        }
        
    	return output;
    }

    /**
     * method accessor untuk mendapatkan solusi terbaik yang terpendek jalannya
     * @return bestSolution
     */
	public int getBestSolution() {
		return bestSolution;
	}

	/**
	 * method mutator setter untuk mengubah nilai bestsolution untuk jalan terpendeknya
	 * @param bestSolution
	 */
	public void setBestSolution(int bestSolution) {
		this.bestSolution = bestSolution;
	}

}
