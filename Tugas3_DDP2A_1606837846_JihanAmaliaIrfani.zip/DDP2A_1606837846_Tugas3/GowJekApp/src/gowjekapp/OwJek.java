/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public class OwJek {
    //instance variables
	private int minYearAllowed; //tahun
	private int minTopSpeed; //kecepatan minimum
	private int minCC; //cc untuk minimum bensin
	private int costPerKm; //rp untuk per kilo nya
	private int first2KmCost; //harga dari 2 kilo awal
	private int first5KmCost; //harga dari 5 kilo awal
	private int fixedCost; //harga yang sudah fix
	private double protectionCost; //harga untuk proteksi
	private int promo; //rupee
	private double jarak;	//hasil perhitungan jarak terpendek
	
	/**
	 * constructor dengan nilai default untuk kelas owjek
	 */
	public OwJek() {
		super();
	}

	/**
	 * constructor dengan nilai sesuai masukan 
	 * @param minYearAllowed
	 * @param minTopSpeed
	 * @param minCC
	 * @param costPerKm
	 * @param first2KmCost
	 * @param first5KmCost
	 * @param fixedCost
	 * @param protectionCost
	 * @param promo
	 * @param jarak
	 */
	public OwJek(int minYearAllowed, int minTopSpeed, int minCC, int costPerKm, int first2KmCost, int first5KmCost,
			int fixedCost, int protectionCost, int promo, double jarak) {
		super();
		this.minYearAllowed = minYearAllowed;
		this.minTopSpeed = minTopSpeed;
		this.minCC = minCC;
		this.costPerKm = costPerKm;
		this.first2KmCost = first2KmCost;
		this.first5KmCost = first5KmCost;
		this.fixedCost = fixedCost;
		this.protectionCost = protectionCost;
		this.promo = promo;
		this.jarak = jarak;
	}

	/**
	 * method accessor getter untuk mendapatkan tahun minimum yang diizinkan
	 * @return minYearAllowed, tahun minimum yang diizinkan
	 */
	public int getMinYearAllowed() {
		return minYearAllowed;
	}

	/**
	 *method mutator setter untuk mengubah nilai minYearAllowed 
	 * @param minYearAllowed
	 */
	public void setMinYearAllowed(int minYearAllowed) {
		this.minYearAllowed = minYearAllowed;
	}

	/**
	 * method accessor getter untuk mendapatkan kecepatan minimum
	 * @return minTopSpeed, kecepatan minimum
	 */
	public int getMinTopSpeed() {
		return minTopSpeed;
	}

	/**
	 *method mutator setter untuk mengubah nilai kecepatan minimum 
	 * @param minTopSpeed
	 */
	public void setMinTopSpeed(int minTopSpeed) {
		this.minTopSpeed = minTopSpeed;
	}

	/**
	 * method accessor getter untuk mendapatkan bensin minimum
	 * @return minCC, kuota bensin minimum
	 */
	public int getMinCC() {
		return minCC;
	}

	/**
	 *method mutator setter untuk mengubah nilai minimum kuota bensin
	 * @param minCC
	 */
	public void setMinCC(int minCC) {
		this.minCC = minCC;
	}

	/**
	 * method accessor getter untuk mendapatkan harga per jaraknya dalam kilometer
	 * @return costPerKm, harga per jaraknya dalam kilometer
	 */
	public int getCostPerKm() {
		return costPerKm;
	}

	/**
	 *method mutator setter untuk mengubah nilai harga per kilometer/jaraknya
	 * @param costPerKm
	 */
	public void setCostPerKm(int costPerKm) {
		this.costPerKm = costPerKm;
	}

	/**
	 * method accessor getter untuk mendapatkan harga dari 2 kilometer awal
	 * @return first2KmCost, harga dari 2 kilometer awal
	 */
	public int getFirst2KmCost() {
		return first2KmCost;
	}

	/**
	 *method mutator setter untuk mengubah nilai harga dari 2 kilometer awal
	 * @param first2KmCost, harga dari 2 kilometer awal
	 */
	public void setFirst2KmCost(int first2KmCost) {
		this.first2KmCost = first2KmCost;
	}

	/**
	 * method accessor getter untuk mendapatkan harga dari 5 kilometer awal
	 * @return first2KmCost, harga dari 5 kilometer awal
	 */
	public int getFirst5KmCost() {
		return first5KmCost;
	}

	/**
	 *method mutator setter untuk mengubah nilai harga dari 5 kilometer awal
	 * @param first2KmCost, harga dari 5 kilometer awal
	 */
	public void setFirst5KmCost(int first5KmCost) {
		this.first5KmCost = first5KmCost;
	}

	/**
	 * method accessor getter untuk mendapatkan harga tambahan
	 * @return fixedCost, harga tambahan
	 */
	public int getFixedCost() {
		return fixedCost;
	}

	/**
	 *method mutator setter untuk mengubah nilai harga dari 5 kilometer awal
	 * @param first2KmCost, harga dari 5 kilometer awal
	 */
	public void setFixedCost(int fixedCost) {
		this.fixedCost = fixedCost;
	}

	/**
	 * method accessor getter untuk mendapatkan harga proteksi 
	 * @return protectionCost, harga proteksi
	 */
	public double getProtectionCost() {	//
		return protectionCost;
	}

	/**
	 *method mutator setter untuk mengubah harga proteksi
	 * @param protectionCost, harga proteksi
	 */
	public void setProtectionCost(double protectionCost) {
		this.protectionCost = protectionCost;
	}

	/**
	 * method accessor getter untuk mendapatkan jarak dalam double 
	 * @return jaraknya dalam double km
	 */
	public double getJarak() {
		return jarak;
	}

	/**
	 *method mutator setter untuk mengubah jarak
	 * @param jaraknya dalam double km
	 */
	public void setJarak(double jarak) {
		this.jarak = jarak;
	}

}
