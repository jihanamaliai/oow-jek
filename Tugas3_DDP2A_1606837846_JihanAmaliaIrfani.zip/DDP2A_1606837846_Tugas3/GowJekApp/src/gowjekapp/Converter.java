/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public class Converter {
	/**
	 * method bantuan untuk mengconvert koordinat
	 * @param str
	 * @return int[] berupa koordinat x dan y
	 */
	public int[] coorConverter(String str){
		//menghold koordinat dalam bentuk string
		String coorX = str.substring(0,2);
		String coorY = str.substring(2,4);
		//untuk kembalian berupa array
		int[] coor = new int[2];
		//untuk perhitungan berdasarkan abjad
		int[] coorMultiple = {0,1,2,3,4,5,6,7,8,9};
		
		//perhitungan dari koordinat berdasarkan konversi 
		int countCoorX = 0;
		int countCoorY = 0;
		
		//untuk penambahan angka disebelah Abjad
		int addCoorX = Integer.parseInt(coorX.substring(1));
		int addCoorY = Integer.parseInt(coorY.substring(1));
		
		//konversi abjad
		//untuk koordinat X
		if(coorX.substring(0,1).equalsIgnoreCase("A")){
			countCoorX += (coorMultiple[0] * 10) + addCoorX;
		}else if (coorX.substring(0,1).equalsIgnoreCase("B")){
			countCoorX += (coorMultiple[1] * 10) + addCoorX;
		}else if (coorX.substring(0,1).equalsIgnoreCase("C")){
			countCoorX += (coorMultiple[2] * 10) + addCoorX;
		}else if (coorX.substring(0,1).equalsIgnoreCase("D")){
			countCoorX += (coorMultiple[3] * 10) + addCoorX;
		}else if (coorX.substring(0,1).equalsIgnoreCase("E")){
			countCoorX += (coorMultiple[4] * 10) + addCoorX;
		}
		coor[0] = countCoorX; //untuk dimasukkan pada array indeks 0 sebagai kooordinat x
		
		//untuk koordinat Y
		if(coorY.substring(0,1).equalsIgnoreCase("Q")){
			countCoorY += (coorMultiple[0] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("R")){
			countCoorY += (coorMultiple[1] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("S")){
			countCoorY += (coorMultiple[2] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("T")){
			countCoorY += (coorMultiple[3] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("U")){
			countCoorY += (coorMultiple[4] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("V")){
			countCoorY += (coorMultiple[5] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("W")){
			countCoorY += (coorMultiple[6] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("X")){
			countCoorY += (coorMultiple[7] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("Y")){
			countCoorY += (coorMultiple[8] * 10) + addCoorY;
		}else if (coorY.substring(0,1).equalsIgnoreCase("Z")){
			countCoorY += (coorMultiple[9] * 10) + addCoorY;
		}
		coor[1] = countCoorY; //untuk dimasukkan pada array indeks 0 sebagai kooordinat x
		
		return coor; //mengembalikan koordinat berupa array
	}
}

