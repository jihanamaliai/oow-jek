/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gowjekapp;

/**
 *
 * @author Jihanai
 */
public class OjRegular extends OwJek implements Calculateable {
	/**
	 * constructor default untuk subclass ini dengan inputan jarak
	 * @param jarak
	 */
	public OjRegular(double jarak){
		super(2012, 0, 0, 1000, 3000, 0, 0, 0, 40, jarak);	//mengambil insvar degan pemanggilan constructor superclass
	}
	
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar dengan jarak terpeneknya
	 * @param koordinat sebelum dan koordinat sesudah
	 * @return total, harga totalnya
	 */
	@Override
	public double getCost(int from, int to){
		//menampung nilai total dengan perhitungan
		//penambahan harga dari 2 kilometer awal + perhitungan pada method getKmSel() - potongan harga 
		double total = this.getFirst2KmCost() + this.getKmSel() - this.getPromo();
		return total;	//mengembalikan harga total
	}
	/**
	 * method accessor getter untuk mendapatkan total harga yang harus dibayar sesuai jaraknya 
	 * dikurangi dengan jarak 2 km
	 * @return hasil perhitungan harga
	 */
	@Override
	public double getKmSel(){
		return 1000*(super.getJarak() - 2);
	}
	
	/**
	 * method accessor getter untuk mendapatkan potongan harga dengan ketentuan
	 * jika ia kurang dari 6 km maka tidak mendapat potongan, dan sebaliknya
	 * @return potongan harga
	 */
	@Override
	public double getPromo(){
		double potongan = 0;	//menampung harga potongan
		int banding = Double.compare(this.getJarak(),6.0); 	//menampung nilai jarak dan yang akan dibandingkan
		if( banding >= 0){	//jika ia lebih dari atau sama dengan 6 (jarak)
			//potongan : (harga 2 km awal + 4 * harga per kilometer) * 40%
			double potongan1 = (this.getFirst2KmCost() + (4 * this.getCostPerKm())) * 40 / 100; //perhitungan harga potongan
			potongan += potongan1; //update nilai potongan harga
		}else if (banding < 0){ //jika kurang dari 6 km (jarak)
			potongan+=0; //tidak ada penambahan harga potongan
		}
		return potongan; //mengembalikan harga potongan
	}
	
}

